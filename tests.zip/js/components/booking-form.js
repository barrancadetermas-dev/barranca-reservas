// ══════════════════════════════════════════════════
// booking-form.js v5.0 — MILA Sistema Inteligente
// • Navegación libre entre pestañas (sin validación forzada)
// • Canal de origen rediseñado (compacto, sin emojis)
// • Nota de Crédito / Voucher como método de pago
// • Validación solo al guardar
// ══════════════════════════════════════════════════

import { can, isDemo } from '../auth/permissions.js';
import { formatARS, toISODate, showToast, getUnitLabel, getUnitColor, getUnitChipHTML, SOURCE_CONFIG } from '../supabase-config.js';
import { logAction } from '../services/audit-service.js';
import { DateRangePicker } from './date-range-picker.js';
import { Bus, EVENTS } from '../services/event-bus.js';
import { cache } from '../services/supabase-cache.js';
import { Sound } from '../services/sound-service.js';
// PriceSuggester se carga lazy en _runPriceSuggestion()

const PAYMENT_METHODS = [
  { value: 'cash',        label: 'Efectivo' },
  { value: 'transfer',    label: 'Transferencia' },
  { value: 'mercadopago', label: 'MercadoPago' },
  { value: 'naranjax',    label: 'Naranja X' },
  { value: 'uala',        label: 'Ualá' },
  { value: 'credit_card', label: 'Tarjeta de Crédito (+10%)' },
  { value: 'debit_card',  label: 'Tarjeta de Débito' },
  { value: 'credit_note', label: 'Nota de Crédito / Voucher' },
];

// Canales de origen disponibles (en orden visual)
// Generado dinámicamente desde SOURCE_CONFIG — única fuente de verdad
const SOURCE_OPTIONS = Object.entries(SOURCE_CONFIG).map(([value, cfg]) => ({
  value,
  label: cfg.label,
  color: cfg.dot ?? cfg.color ?? '#64748B',
}));

export class BookingForm {
  constructor(supabase, ctx) {
    this.db  = supabase;
    this.ctx = ctx;
    this._currentStep = 1;
    this._totalSteps  = 5;
    this._editingId   = null;
    this._selectedGuestId = null;
    this._selectedUnitIds = new Set();
    this._datePicker   = null;
    this._payRowCount  = 0;
    this._priceSuggester = null; // lazy init
    this._suggestTimer   = null;
    this._cachedTotal = 0;
    this._currentDetailBookingId = null;

    this._bindEvents();
  }

  // ── Bind eventos globales del formulario ──────────
  _bindEvents() {
    document.getElementById('booking-modal-close')?.addEventListener('click', () => this.close());
    document.getElementById('btn-booking-cancel')?.addEventListener('click',  () => this.close());
    document.getElementById('btn-step-next')?.addEventListener('click', () => this._nextStep());
    document.getElementById('btn-step-back')?.addEventListener('click', () => this._prevStep());
    document.getElementById('btn-add-payment-row')?.addEventListener('click', () => this._addPaymentRow());

    // Precio/descuento → recalcular breakdown
    ['f-price','f-discount','f-surcharge','f-free-nights'].forEach(id => {
      document.getElementById(id)?.addEventListener('input', () => this._updateBreakdown());
    });

    // Notas counter
    document.getElementById('f-notes')?.addEventListener('input', e => {
      document.getElementById('notes-count').textContent = e.target.value.length;
    });

    // Búsqueda de huéspedes
    let guestSearchTimer;
    document.getElementById('guest-search')?.addEventListener('input', e => {
      clearTimeout(guestSearchTimer);
      guestSearchTimer = setTimeout(() => this._searchGuests(e.target.value.trim()), 300);
    });

    // Navegación libre: clic en step indicator
    document.querySelectorAll('.step-item').forEach((el, i) => {
      el.style.cursor = 'pointer';
      el.addEventListener('click', () => this._goToStep(i + 1));
    });

    // Inicializar selector de canal de origen (compacto)
    this._renderSourceSelector();
  }

  // ── Renderizar selector de canal (compacto, sin emojis) ──
  _renderSourceSelector(value = 'direct') {
    const container = document.getElementById('f-source-selector');
    if (!container) return;

    // Siempre regenerar desde SOURCE_OPTIONS (única fuente de verdad)
    container.innerHTML = SOURCE_OPTIONS.map(s => `
      <label class="src-chip" data-source="${s.value}" style="--src-color:${s.color}">
        <input type="radio" name="booking-source" value="${s.value}"
               ${s.value === value ? 'checked' : ''} style="display:none">
        <span class="src-dot" style="background:${s.color}"></span>
        <span class="src-label">${s.label}</span>
      </label>`).join('');

    container.querySelectorAll('.src-chip[data-source]').forEach(chip => {
      chip.addEventListener('click', (e) => {
        e.preventDefault();
        container.querySelectorAll('.src-chip').forEach(c => {
          c.classList.remove('selected');
          const inp = c.querySelector('input');
          if (inp) inp.checked = false;
        });
        chip.classList.add('selected');
        const inp = chip.querySelector('input');
        if (inp) inp.checked = true;
      });
    });

    // Set default selection
    const defaultChip = container.querySelector(`.src-chip[data-source="${value}"]`);
    if (defaultChip) {
      defaultChip.classList.add('selected');
      const inp = defaultChip.querySelector('input');
      if (inp) inp.checked = true;
    }
  }

  // ── Abrir para nueva reserva ──────────────────────
  open(prefill = {}) {
    this._editingId = null;
    this._reset();
    document.getElementById('booking-modal-title').textContent = 'Nueva Reserva';
    document.getElementById('btn-step-next').textContent = 'Continuar →';

    if (prefill.unitId) {
      this._selectedUnitIds.add(String(prefill.unitId));
      this._renderUnitSelector();
    }
    if (prefill.checkIn || prefill.checkOut) {
      this._datePicker?.setValue(prefill.checkIn ?? null, prefill.checkOut ?? null);
      if (prefill.checkIn)  document.getElementById('f-checkin').value  = prefill.checkIn;
      if (prefill.checkOut) document.getElementById('f-checkout').value = prefill.checkOut;
      this._updateBreakdown();
    }
    // Precarga desde calculadora (paso 0)
    if (prefill.price) {
      const priceEl = document.getElementById('f-price');
      if (priceEl) priceEl.value = prefill.price;
      this._updateBreakdown();
    }
    if (prefill.source) {
      const container = document.getElementById('f-source-selector');
      if (container) {
        container.querySelectorAll('.src-chip').forEach(c => c.classList.remove('selected'));
        const chip = container.querySelector(`.src-chip[data-source="${prefill.source}"]`);
        if (chip) {
          chip.classList.add('selected');
          const inp = chip.querySelector('input');
          if (inp) inp.checked = true;
        }
      }
    }
    if (prefill.discountPct !== undefined) {
      const discEl = document.getElementById('f-discount');
      if (discEl) discEl.value = prefill.discountPct;
    }

    document.getElementById('overlay-booking').classList.remove('hidden');

    // Historial de precios — se carga async en background
    if (prefill.unitId) this._loadPriceHistory(prefill.unitId);
  }

  // ── Abrir para editar reserva existente ───────────
  async openEdit(bookingId) {
    document.getElementById('booking-modal-title').textContent = 'Editar Reserva';
    this._reset();
    this._editingId = bookingId;

    try {
      const { data: b, error } = await this.db
        .from('bookings')
        .select('*, guests!bookings_guest_id_fkey(*), booking_units(unit_id), payments(*)')
        .eq('id', bookingId).single();

      if (error) throw error;
      if (!b) { showToast('No se encontró la reserva', 'error'); return; }

      // Rellenar huésped
      const g = b.guests ?? {};
      this._selectedGuestId = g.id ?? null;
      ['firstname','lastname','dni','phone','email'].forEach(f => {
        const el = document.getElementById(`f-${f}`);
        if (el) el.value = g[f === 'firstname' ? 'first_name' : f === 'lastname' ? 'last_name' : f] ?? '';
      });

      // Canal de origen
      const sourceContainer = document.getElementById('f-source-selector');
      if (sourceContainer) {
        sourceContainer.querySelectorAll('.src-chip').forEach(c => c.classList.remove('selected'));
        const chip = sourceContainer.querySelector(`.src-chip[data-source="${b.source ?? 'direct'}"]`);
        if (chip) { chip.classList.add('selected'); chip.querySelector('input').checked = true; }
      }

      // Unidades
      this._selectedUnitIds = new Set((b.booking_units ?? []).map(bu => String(bu.unit_id)));
      this._renderUnitSelector();

      // Fechas
      if (this._datePicker && b.check_in && b.check_out) {
        this._datePicker.setValue(b.check_in, b.check_out);
      }
      if (b.check_in)  document.getElementById('f-checkin').value  = b.check_in;
      if (b.check_out) document.getElementById('f-checkout').value = b.check_out;

      const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };
      setVal('f-price',       b.price_per_night ?? '');
      setVal('f-discount',    b.discount_pct    ?? 0);
      setVal('f-surcharge',   b.surcharge_amount ?? 0);
      setVal('f-free-nights', b.free_nights     ?? 0);
      setVal('f-deposit',     b.deposit_amount  ?? 0);
      setVal('f-notes',       b.notes           ?? '');
      document.getElementById('notes-count').textContent = (b.notes ?? '').length;
      // Pax
      if (document.getElementById('f-adults'))   document.getElementById('f-adults').value   = b.adults   ?? b.pax ?? 2;
      if (document.getElementById('f-children')) document.getElementById('f-children').value = b.children ?? 0;

      this._updateBreakdown();
      this._updateBlockedDates();

      // Pagos existentes
      (b.payments ?? []).forEach(p => this._addPaymentRow(p));
      this._updatePaymentSummary();

      document.getElementById('btn-step-next').textContent = 'Guardar cambios';
      document.getElementById('overlay-booking').classList.remove('hidden');
    } catch (err) {
      console.error('[BookingForm] openEdit error:', err);
      showToast('Error al cargar reserva', 'error');
    }
  }

  // ── openDetail ────────────────────────────────────
  openDetail(booking) {
    if (!booking?.id) return;
    this._currentDetailBookingId = booking.id;
    const overlay = document.getElementById('overlay-detail');
    const body    = document.getElementById('detail-body');
    if (!overlay || !body) return;

    const guest      = booking.guests
      ? `${booking.guests.first_name ?? ''} ${booking.guests.last_name ?? ''}`.trim()
      : 'Sin nombre';
    const unitNames  = (booking.booking_units ?? [])
      .map(bu => bu.units?.name ?? '').filter(Boolean).join(', ');
    const srcCfg     = SOURCE_CONFIG?.[booking.source] ?? { label: booking.source ?? 'Directo', dot: '#64748b' };
    const badgeColor = srcCfg.dot ?? srcCfg.color ?? '#64748b';
    const statusLabels = { pending:'Sin seña', partial:'Con seña', paid:'Pagado',
                           cancelled:'Cancelada', blocked:'Bloqueada' };
    const hasBadExp  = booking.guests?.bad_experience;

    // Desglose financiero completo
    const nights        = booking.nights ?? 0;
    const pricePerNight = booking.price_per_night ?? 0;
    const discPct       = booking.discount_pct ?? 0;
    const surcharge     = booking.surcharge_amount ?? 0;
    const freeNights    = booking.free_nights ?? 0;
    const billable      = Math.max(0, nights - freeNights);
    const subtotal      = pricePerNight * billable;
    const discAmt       = subtotal * (discPct / 100);
    const total         = booking.total_amount ?? Math.max(0, subtotal - discAmt + surcharge);
    const totalPaid     = booking.total_paid ?? 0;
    const balance       = booking.balance ?? (total - totalPaid);

    // Botones check-in/out
    const now   = new Date();
    const ciDate = new Date(booking.check_in + 'T12:00:00');
    const showCI = !booking.checked_in_at  && ciDate <= now && booking.status !== 'cancelled';
    const showCO = !!booking.checked_in_at && !booking.checked_out_at && booking.status !== 'cancelled';
    const ciBtn = document.getElementById('detail-checkin-btn');
    const coBtn = document.getElementById('detail-checkout-btn');
    if (ciBtn) ciBtn.style.display = showCI ? '' : 'none';
    if (coBtn) coBtn.style.display = showCO ? '' : 'none';

    body.innerHTML = `
      ${hasBadExp ? `<div style="background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:var(--r-md);padding:8px 12px;font-size:.78rem;color:#dc2626">
        ⚠️ <strong>Atención:</strong> Huésped con antecedentes de mala experiencia.
      </div>` : ''}
      <div class="detail-header-row">
        <div>
          <div class="detail-guest-name">${guest}</div>
          <div class="detail-meta">
            <span class="chip" style="background:${badgeColor}20;color:${badgeColor}">■ ${srcCfg.label}</span>
            <span class="detail-unit">${unitNames}</span>
          </div>
        </div>
        <div class="detail-status">
          <span class="status-badge status-${booking.status}">${statusLabels[booking.status] ?? booking.status}</span>
        </div>
      </div>
      <div class="detail-dates">
        <div>
          <span class="detail-label">Check-in</span>
          <strong>${booking.check_in}</strong>
          ${booking.checked_in_at ? `<span style="font-size:.65rem;color:var(--color-success);display:block">✓ Registrado</span>` : ''}
        </div>
        <div class="detail-nights">
          ${nights} noche${nights !== 1 ? 's' : ''}
          ${(booking.pax || booking.adults) ? `<br><span style="font-size:.72rem;color:var(--color-text-3)">👥 ${booking.adults ?? booking.pax ?? 1} adulto${(booking.adults ?? 1) !== 1 ? 's' : ''}${booking.children ? ` + ${booking.children} menor${booking.children !== 1 ? 'es' : ''}` : ''}</span>` : ''}
        </div>
        <div style="text-align:right">
          <span class="detail-label">Check-out</span>
          <strong>${booking.check_out}</strong>
          ${booking.checked_out_at ? `<span style="font-size:.65rem;color:var(--color-success);display:block">✓ Registrado</span>` : ''}
        </div>
      </div>
      <div class="detail-breakdown">
        ${pricePerNight > 0 ? `
          <div class="detail-breakdown-row">
            <span>Precio por noche</span>
            <span>${formatARS(pricePerNight)}</span>
          </div>
          <div class="detail-breakdown-row">
            <span>Noches${freeNights > 0 ? ` (${nights} − ${freeNights} gratis)` : ` × ${nights}`}</span>
            <span>${billable} fact.</span>
          </div>
          <div class="detail-breakdown-row">
            <span>Subtotal</span>
            <span>${formatARS(subtotal)}</span>
          </div>
          ${discPct > 0 ? `<div class="detail-breakdown-row" style="color:var(--color-success)"><span>Descuento ${discPct}%</span><span>−${formatARS(discAmt)}</span></div>` : ''}
          ${surcharge > 0 ? `<div class="detail-breakdown-row" style="color:var(--color-warning)"><span>Recargo / extra</span><span>+${formatARS(surcharge)}</span></div>` : ''}
        ` : ''}
        <div class="detail-breakdown-row total-row">
          <span>Total</span>
          <span>${formatARS(total)}</span>
        </div>
        ${totalPaid > 0 ? `<div class="detail-breakdown-row paid-row"><span>Pagado</span><span>${formatARS(totalPaid)}</span></div>` : ''}
        <div class="detail-breakdown-row balance-row" style="color:${balance > 0 ? 'var(--color-warning)' : 'var(--color-success)'}">
          <span>${balance > 0 ? '⚠ Saldo pendiente' : '✓ Saldado'}</span>
          <span style="font-size:1.05rem">${formatARS(Math.abs(balance))}</span>
        </div>
      </div>
      ${booking.notes ? `<div class="detail-notes"><span class="detail-label">Notas</span><p>${booking.notes}</p></div>` : ''}
    `;

    if (booking.payments?.length) {
      const payHtml = booking.payments
        .filter(p => p.amount !== 0)
        .map(p => {
          const pm    = PAYMENT_METHODS.find(m => m.value === p.method)?.label ?? p.method;
          const isNeg = p.amount < 0;
          return `<div class="pay-row-detail">
            <span>${isNeg ? '↩ Devolución' : pm}</span>
            <span style="font-size:.72rem;color:var(--color-text-3)">${p.payment_date ?? ''}</span>
            <span style="color:${isNeg?'var(--color-warning)':'var(--color-success)'};font-weight:600">${isNeg?'−':'+'}${formatARS(Math.abs(p.amount))}</span>
          </div>`;
        }).join('');
      body.innerHTML += `<div class="detail-payments"><div class="detail-label" style="margin-bottom:8px">Historial de Pagos</div>${payHtml}</div>`;
    }

    overlay.classList.remove('hidden');
    requestAnimationFrame(() => document.getElementById('detail-close')?.focus());
  }

  close() {
    document.getElementById('overlay-booking').classList.add('hidden');
    this._reset();
  }

  // ── Reset completo del form ───────────────────────
  _reset() {
    this._currentStep     = 1;
    this._editingId       = null;
    this._selectedGuestId = null;
    this._selectedUnitIds = new Set();
    this._payRowCount     = 0;
    this._cachedTotal     = 0;

    ['f-firstname','f-lastname','f-dni','f-phone','f-email','f-notes',
     'f-price','f-discount','f-surcharge','f-free-nights','f-deposit',
     'f-checkin','f-checkout'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.value = ['f-discount','f-surcharge','f-free-nights','f-deposit'].includes(id) ? '0' : '';
    });

    document.getElementById('notes-count').textContent  = '0';
    document.getElementById('guest-search').value       = '';
    // Reset pax
    const adultsEl = document.getElementById('f-adults');
    if (adultsEl) adultsEl.value = '2';
    const childEl = document.getElementById('f-children');
    if (childEl) childEl.value = '0';
    const paxNumEl = document.getElementById('pax-total-num');
    if (paxNumEl) paxNumEl.textContent = '2';
    const paxLblEl = document.getElementById('pax-total-label');
    if (paxLblEl) paxLblEl.textContent = 'personas en total';
    const paxHidEl = document.getElementById('f-pax');
    if (paxHidEl) paxHidEl.value = '2';
    document.getElementById('guest-results')?.classList.add('hidden');
    const badAlert = document.getElementById('bad-exp-booking-alert-container');
    if (badAlert) badAlert.innerHTML = '';
    document.getElementById('payments-container').innerHTML = '';

    // Source → direct
    this._renderSourceSelector();

    // Date picker
    const dpContainer = document.getElementById('f-date-picker');
    if (dpContainer) {
      this._datePicker = new DateRangePicker(dpContainer, {
        onChange: (start, end) => {
          document.getElementById('f-checkin').value  = start ?? '';
          document.getElementById('f-checkout').value = end   ?? '';
          this._updateBreakdown();
          this._updateBlockedDates();
          this._triggerPriceSuggestion();
        }
      });
    }

    this._renderUnitSelector();
    this._updateBreakdown();
    this._goToStep(1);
  }

  // ── Renderizar selector de unidades ──────────────
  _renderUnitSelector() {
    const container = document.getElementById('units-selector');
    if (!container) return;
    if (!this.ctx.units?.length) {
      container.innerHTML = '<p style="font-size:.8rem;color:var(--color-text-3);padding:8px">Sin unidades configuradas.</p>';
      return;
    }
    container.innerHTML = this.ctx.units.map(u => {
      const selected = this._selectedUnitIds.has(String(u.id));
      const color    = u.color ?? '#6366f1';
      return `
        <label class="unit-option ${selected ? 'selected' : ''}"
               data-unit-id="${u.id}" style="cursor:pointer">
          <span style="width:12px;height:12px;border-radius:50%;
            background:${color};flex-shrink:0;display:inline-block"></span>
          <span class="unit-option-name">${u.name}</span>
          ${u.max_guests ? `<span class="unit-option-detail">hasta ${u.max_guests} huéspedes</span>` : ''}
          <input type="checkbox" ${selected ? 'checked' : ''} style="accent-color:${color};margin-left:auto">
        </label>`;
    }).join('');

    container.querySelectorAll('.unit-option[data-unit-id]').forEach(chip => {
      chip.addEventListener('click', (e) => {
        e.preventDefault();
        const uid = String(chip.dataset.unitId);
        const cb  = chip.querySelector('input[type="checkbox"]');
        if (this._selectedUnitIds.has(uid)) {
          this._selectedUnitIds.delete(uid);
          chip.classList.remove('selected');
          if (cb) cb.checked = false;
        } else {
          this._selectedUnitIds.add(uid);
          chip.classList.add('selected');
          if (cb) cb.checked = true;
          // Cargar historial de precio para la unidad seleccionada
          this._loadPriceHistory(uid);
        }
        this._updateBlockedDates();
        this._updateBreakdown();
        this._triggerPriceSuggestion();
        // Update pax cap when unit changes
        this._updatePaxCap?.();
      });
    });

    // Render pax selector si hay contenedor
    this._renderPaxSelector();
  }

  // ── Selector de cantidad de personas ─────────────
  _renderPaxSelector() {
    const getMaxPax = () => {
      // Capacidad máxima = suma de max_guests de unidades seleccionadas
      // (permite multi-unidad: ej. 2 deptos para 8 personas)
      if (!this._selectedUnitIds?.size) return 99;
      const units = this.ctx?.units ?? [];
      let total = 0;
      this._selectedUnitIds.forEach(uid => {
        const u = units.find(u => String(u.id) === String(uid));
        if (u?.max_guests) total += u.max_guests;
      });
      return total > 0 ? total : 99;
    };

    const updateTotal = () => {
      const adults   = parseInt(document.getElementById('f-adults')?.value   ?? '1');
      const children = parseInt(document.getElementById('f-children')?.value ?? '0');
      const total    = adults + children;
      const maxPax   = getMaxPax();
      const numEl    = document.getElementById('pax-total-num');
      const lblEl    = document.getElementById('pax-total-label');
      const paxHid   = document.getElementById('f-pax');
      const capHint  = document.getElementById('pax-cap-hint');
      if (numEl) numEl.textContent = total;
      if (lblEl) lblEl.textContent = total === 1 ? 'persona en total' : 'personas en total';
      if (paxHid) paxHid.value = total;
      if (capHint && maxPax < 99) {
        const over = total > maxPax;
        capHint.textContent = over
          ? `⚠️ Excede el máximo (${maxPax})`
          : `máx. ${maxPax}`;
        capHint.style.color = over ? '#ef4444' : '';
      }
    };

    const bind = (btnId, inputId, delta) => {
      const btn = document.getElementById(btnId);
      if (!btn) return;
      const fresh = btn.cloneNode(true);
      btn.parentNode.replaceChild(fresh, btn);
      fresh.addEventListener('click', (e) => {
        e.preventDefault();
        const inp      = document.getElementById(inputId);
        if (!inp) return;
        const min      = parseInt(inp.min ?? '0');
        const maxPax   = getMaxPax();
        const isAdults = inputId === 'f-adults';
        const other    = isAdults
          ? parseInt(document.getElementById('f-children')?.value ?? '0')
          : parseInt(document.getElementById('f-adults')?.value   ?? '1');
        const cur      = parseInt(inp.value ?? '0');
        const next     = Math.max(min, cur + delta);
        // Enforce total cap
        if (delta > 0 && (next + other) > maxPax) {
          const capHint = document.getElementById('pax-cap-hint');
          if (capHint) {
            capHint.textContent = `⚠️ Máximo ${maxPax} huéspedes`;
            capHint.style.color = '#ef4444';
            setTimeout(() => { capHint.textContent = `máx. ${maxPax}`; capHint.style.color = ''; }, 1500);
          }
          return;
        }
        inp.value = next;
        updateTotal();
      });
    };

    bind('adults-minus',   'f-adults',   -1);
    bind('adults-plus',    'f-adults',   +1);
    bind('children-minus', 'f-children', -1);
    bind('children-plus',  'f-children', +1);
    updateTotal();

    // Re-run when unit selection changes to update cap
    this._updatePaxCap = updateTotal;
  }

  // ── Sugeridor de precio dinámico ─────────────────
  _triggerPriceSuggestion() {
    clearTimeout(this._suggestTimer);
    this._suggestTimer = setTimeout(() => this._runPriceSuggestion(), 500);
  }

  async _runPriceSuggestion() {
    const ci       = document.getElementById('f-checkin')?.value;
    const co       = document.getElementById('f-checkout')?.value;
    const unitIds  = [...this._selectedUnitIds];
    const container = document.getElementById('price-suggestion-container');
    if (!container) return;

    if (!ci || !co || !unitIds.length) {
      container.innerHTML = '';
      return;
    }

    // Lazy load PriceSuggester
    if (!this._priceSuggester) {
      try {
        const mod = await import('../services/price-suggester.js');
        if (mod?.PriceSuggester) {
          this._priceSuggester = new mod.PriceSuggester(this.db, this.ctx);
          this._PriceSuggesterClass = mod.PriceSuggester;
        }
      } catch(e) {
        container.innerHTML = '';
        return;
      }
    }
    if (!this._priceSuggester) return;

    container.innerHTML = '<div class="ps-loading">⟳ Analizando historial...</div>';

    try {
      const currentPrice = parseFloat(document.getElementById('f-price')?.value) || 0;
      const result = await this._priceSuggester.suggest(unitIds, ci, co);
      container.innerHTML = this._PriceSuggesterClass.renderPanel(result, currentPrice);

      // Bind "Usar este precio" button
      container.querySelector('.ps-use')?.addEventListener('click', (e) => {
        const price = parseFloat(e.target.dataset.price);
        if (!price) return;
        const priceEl = document.getElementById('f-price');
        if (priceEl) {
          priceEl.value = price;
          priceEl.dispatchEvent(new Event('input'));
          // Brief highlight
          priceEl.style.borderColor = '#22c55e';
          priceEl.style.boxShadow = '0 0 0 2px #22c55e28';
          setTimeout(() => { priceEl.style.borderColor=''; priceEl.style.boxShadow=''; }, 1800);
        }
        showToast('Precio sugerido aplicado ✓', 'success');
      });
    } catch (err) {
      container.innerHTML = '';
    }
  }

  // ── Calcular fechas bloqueadas para el picker ─────
  async _updateBlockedDates() {
    if (!this._datePicker || !this._selectedUnitIds.size) return;
    const unitIds = [...this._selectedUnitIds];
    const today   = toISODate(new Date());
    try {
      const { data } = await this.db
        .from('bookings')
        .select('id, check_in, check_out, booking_units(unit_id)')
        .eq('hotel_id', this.ctx.hotelId)
        .neq('status', 'cancelled')
        .gte('check_out', today);

      if (!data) return;
      const blocked = new Set();
      data.forEach(b => {
        if (this._editingId && b.id === this._editingId) return;
        const units = (b.booking_units ?? []).map(bu => bu.unit_id);
        if (!units.some(uid => unitIds.includes(uid))) return;
        let d = new Date(b.check_in + 'T00:00:00');
        const end = new Date(b.check_out + 'T00:00:00');
        while (d < end) { blocked.add(toISODate(d)); d.setDate(d.getDate() + 1); }
      });
      this._datePicker.setBlockedDates([...blocked]);
    } catch (_) {}
  }

  // ── Navegación de pasos — LIBRE (sin validación forzada) ──
  _goToStep(step) {
    this._currentStep = step;

    document.querySelectorAll('.step-content').forEach((el, i) => {
      el.classList.toggle('active',  i + 1 === step);
      el.classList.toggle('hidden',  i + 1 !== step);
    });

    document.querySelectorAll('.step-item').forEach((el, i) => {
      el.classList.toggle('active',    i + 1 === step);
      el.classList.toggle('completed', i + 1 < step);
    });

    const backBtn  = document.getElementById('btn-step-back');
    const nextBtn  = document.getElementById('btn-step-next');
    const footer   = document.querySelector('.modal-footer');

    // En paso 5 (voucher): ocultar footer normal, mostrar acciones del voucher
    const onVoucher = step === 5;
    if (footer) footer.style.display = onVoucher ? 'none' : '';
    if (backBtn) backBtn.style.visibility = (step > 1 && !onVoucher) ? 'visible' : 'hidden';
    if (nextBtn) nextBtn.textContent = step === 4
      ? 'Ver Resumen →'
      : step < 4
      ? 'Continuar →'
      : 'Continuar →';

    if (step === 4) this._updatePaymentSummary();
    if (step === 5) this._renderVoucher();
  }

  // Continuar → siguiente paso O mostrar voucher en paso 5
  _nextStep() {
    if (this._currentStep < this._totalSteps) {
      if (this._currentStep === 4 && !this._validateAll()) return; // validar antes del voucher
      this._goToStep(this._currentStep + 1);
    }
  }

  _prevStep() {
    if (this._currentStep > 1) this._goToStep(this._currentStep - 1);
  }

  // ── Validación completa — solo al guardar ─────────
  _validateAll() {
    // Clear previous errors
    document.querySelectorAll('.field-error').forEach(el => {
      el.classList.remove('field-error');
    });

    const fn    = document.getElementById('f-firstname').value.trim();
    const ln    = document.getElementById('f-lastname').value.trim();
    const ci    = document.getElementById('f-checkin').value;
    const co    = document.getElementById('f-checkout').value;
    const price = parseFloat(document.getElementById('f-price').value);

    // Collect all errors, navigate to first failing step
    let firstStep = null;
    const fail = (id, stepNum, msg) => {
      const el = document.getElementById(id);
      if (el) { el.classList.add('field-error'); el.focus?.(); }
      if (!firstStep || stepNum < firstStep.step) {
        firstStep = { step: stepNum, msg };
      }
    };

    if (!fn) fail('f-firstname', 1, 'Nombre requerido');
    if (!ln) fail('f-lastname',  1, 'Apellido requerido');
    if (!this._selectedUnitIds.size) {
      // Units selector — highlight the container
      const sel = document.getElementById('units-selector');
      if (sel) sel.classList.add('field-error');
      if (!firstStep || 2 < firstStep.step) firstStep = { step: 2, msg: 'Seleccioná al menos una unidad' };
    }
    if (!ci) fail('f-date-picker', 2, 'Seleccioná fechas de estadía');
    if (!co) fail('f-date-picker', 2, 'Seleccioná fechas de estadía');
    if (ci && co && ci >= co) {
      fail('f-date-picker', 2, 'El check-out debe ser posterior al check-in');
    }
    if (!price || price <= 0) fail('f-price', 3, 'Ingresá el precio por noche');

    if (firstStep) {
      this._goToStep(firstStep.step);
      showToast(firstStep.msg, 'warning');
      Sound?.error?.();
      return false;
    }
    return true;
  }

  // ── Precio breakdown ──────────────────────────────
  _updateBreakdown() {
    const ci    = document.getElementById('f-checkin').value;
    const co    = document.getElementById('f-checkout').value;
    const price = parseFloat(document.getElementById('f-price').value) || 0;
    const disc  = parseFloat(document.getElementById('f-discount').value) || 0;
    const surch = parseFloat(document.getElementById('f-surcharge').value) || 0;
    const freeN = parseInt(document.getElementById('f-free-nights').value) || 0;

    if (!ci || !co || !price) {
      ['pb-nights','pb-subtotal','pb-discount','pb-surcharge','pb-total','pb-free-nights']
        .forEach(id => { const el = document.getElementById(id); if (el) el.textContent = '—'; });
      return;
    }

    const nights   = Math.round((new Date(co) - new Date(ci)) / 86400000);
    const billable = Math.max(0, nights - freeN);
    const subtotal = price * billable;
    const discAmt  = subtotal * (disc / 100);
    const total    = Math.max(0, subtotal - discAmt + surch);

    const set = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; };
    set('pb-nights',     `${nights} noche${nights !== 1 ? 's' : ''}`);
    set('pb-subtotal',   formatARS(subtotal));
    set('pb-free-nights', freeN > 0 ? `−${formatARS(price * freeN)}` : '—');
    set('pb-discount',   disc > 0 ? `−${formatARS(discAmt)} (${disc}%)` : '—');
    set('pb-surcharge',  surch > 0 ? `+${formatARS(surch)}` : '—');
    set('pb-total',      formatARS(total));

    document.getElementById('pbr-free-nights')?.style.setProperty('display', freeN > 0 ? '' : 'none');
    document.getElementById('pbr-discount')?.style.setProperty('display',    disc > 0 ? '' : 'none');
    document.getElementById('pbr-surcharge')?.style.setProperty('display',   surch > 0 ? '' : 'none');

    this._cachedTotal = total;
    this._updatePaymentSummary();
  }

  // ── Manejo de pagos ───────────────────────────────
  _addPaymentRow(existing = null) {
    const rowId  = `pay-row-${++this._payRowCount}`;
    const today  = toISODate(new Date());
    const isFx   = existing?.currency === 'USD';
    const rate   = existing?.exchange_rate ?? '';
    const row    = document.createElement('div');
    row.className = 'payment-row';
    row.id = rowId;
    row.innerHTML = `
      <div class="pay-grid">
        <select class="pay-method form-control">
          ${PAYMENT_METHODS.map(m =>
            `<option value="${m.value}" ${existing?.method === m.value ? 'selected' : ''}>${m.label}</option>`
          ).join('')}
        </select>
        <div class="pay-currency-toggle" title="Cambiar moneda">
          <button type="button" class="pay-cur-btn ${!isFx ? 'active' : ''}" data-cur="ARS">$ARS</button>
          <button type="button" class="pay-cur-btn ${isFx ? 'active' : ''}"  data-cur="USD">USD</button>
        </div>
        <input type="number" class="pay-amount form-control" placeholder="Monto" min="0" step="100"
               value="${existing?.amount ?? ''}">
        <div class="pay-usd-rate ${!isFx ? 'hidden' : ''}">
          <span style="font-size:.7rem;color:var(--color-text-3)">Cotiz.</span>
          <input type="number" class="pay-rate form-control" placeholder="1480" min="0" step="1"
                 value="${rate}" style="width:80px">
          <span class="pay-ars-equiv" style="font-size:.72rem;color:var(--color-text-2)"></span>
        </div>
        <input type="date" class="pay-date form-control" value="${existing?.payment_date ?? today}">
        <button class="btn btn-icon btn-danger-icon pay-remove" title="Eliminar">×</button>
      </div>
      <div class="credit-surcharge-info" style="display:none;font-size:.75rem;color:var(--color-warning);margin-top:4px">
        +10% recargo tarjeta: <span id="${rowId}-cc-surcharge">$0</span>
      </div>`;

    // Currency toggle
    row.querySelectorAll('.pay-cur-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const cur = btn.dataset.cur;
        row.querySelectorAll('.pay-cur-btn').forEach(b => b.classList.toggle('active', b.dataset.cur === cur));
        row.querySelector('.pay-usd-rate').classList.toggle('hidden', cur !== 'USD');
        row.dataset.currency = cur;
        this._updateUsdEquiv(row);
        this._updatePaymentSummary();
      });
    });
    row.dataset.currency = isFx ? 'USD' : 'ARS';

    // Rate input → recalculate equiv
    row.querySelector('.pay-rate').addEventListener('input', () => this._updateUsdEquiv(row));

    row.querySelector('.pay-remove').addEventListener('click', () => {
      row.remove(); this._updatePaymentSummary();
    });
    row.querySelector('.pay-method').addEventListener('change', () => {
      this._updateCreditSurcharge(row); this._updatePaymentSummary();
    });
    row.querySelector('.pay-amount').addEventListener('input', () => {
      this._updateCreditSurcharge(row); this._updateUsdEquiv(row); this._updatePaymentSummary();
    });

    document.getElementById('payments-container').appendChild(row);
    if (existing) { this._updateCreditSurcharge(row); this._updateUsdEquiv(row); }
  }

  _updateUsdEquiv(row) {
    const cur    = row.dataset.currency;
    const equiv  = row.querySelector('.pay-ars-equiv');
    if (!equiv || cur !== 'USD') return;
    const usd    = parseFloat(row.querySelector('.pay-amount')?.value) || 0;
    const rate   = parseFloat(row.querySelector('.pay-rate')?.value)   || 0;
    if (usd && rate) {
      equiv.textContent = `= ${formatARS(usd * rate)}`;
    } else {
      equiv.textContent = rate ? `× ${formatARS(rate)}` : '';
    }
  }

  _updateCreditSurcharge(row) {
    const method = row.querySelector('.pay-method').value;
    const amount = parseFloat(row.querySelector('.pay-amount').value) || 0;
    const isCc   = method === 'credit_card';
    const ccInfo = row.querySelector('.credit-surcharge-info');
    const ccSpan = row.querySelector(`#${row.id}-cc-surcharge`);
    if (ccInfo) ccInfo.style.display = isCc ? 'block' : 'none';
    if (ccSpan) ccSpan.textContent = formatARS(isCc ? amount * 0.10 : 0);
  }

  _getTotalPaid() {
    let total = 0;
    document.querySelectorAll('.payment-row').forEach(row => {
      const rawAmt = parseFloat(row.querySelector('.pay-amount')?.value) || 0;
      const cur    = row.dataset?.currency ?? 'ARS';
      const rate   = parseFloat(row.querySelector('.pay-rate')?.value) || 1;
      const amt    = cur === 'USD' ? rawAmt * rate : rawAmt;
      const isCc   = row.querySelector('.pay-method')?.value === 'credit_card';
      total += isCc ? amt * 1.10 : amt;
    });
    return total;
  }

  _updatePaymentSummary() {
    const total   = this._cachedTotal ?? 0;
    const paid    = this._getTotalPaid();
    const balance = total - paid;
    const set = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; };
    set('ps-total',   formatARS(total));
    set('ps-paid',    formatARS(paid));
    set('ps-balance', formatARS(Math.max(0, balance)));
  }

  // ── Búsqueda de huéspedes ─────────────────────────
  async _searchGuests(q) {
    const container = document.getElementById('guest-results');
    if (!container) return;
    if (q.length < 2) { container.classList.add('hidden'); return; }

    const { data } = await this.db
      .from('guests')
      .select('id, first_name, last_name, dni, phone, bad_experience, tags')
      .eq('hotel_id', this.ctx.hotelId)
      .or(`first_name.ilike.%${q}%,last_name.ilike.%${q}%,dni.ilike.%${q}%`)
      .limit(6);

    if (!data?.length) { container.classList.add('hidden'); return; }

    container.innerHTML = data.map(g => {
      const isBad = g.bad_experience || (g.tags ?? []).includes('no_recomendar');
      const isVIP = (g.tags ?? []).includes('vip');
      return `<div class="guest-result-item ${isBad ? 'bad-exp' : ''}" data-id="${g.id}"
           data-fn="${g.first_name ?? ''}" data-ln="${g.last_name ?? ''}"
           data-dni="${g.dni ?? ''}" data-phone="${g.phone ?? ''}">
        ${isBad ? '⚠️ ' : isVIP ? '⭐ ' : ''}${g.first_name} ${g.last_name}
        ${g.dni ? `<span class="result-meta">${g.dni}</span>` : ''}
      </div>`;
    }).join('');

    container.querySelectorAll('.guest-result-item').forEach(item => {
      item.addEventListener('click', async () => {
        this._selectedGuestId = item.dataset.id;
        document.getElementById('f-firstname').value = item.dataset.fn;
        document.getElementById('f-lastname').value  = item.dataset.ln;
        document.getElementById('f-dni').value       = item.dataset.dni;
        document.getElementById('f-phone').value     = item.dataset.phone;
        document.getElementById('guest-search').value = '';
        container.classList.add('hidden');

        const guest = data.find(g => g.id === item.dataset.id);
        const alertContainer = document.getElementById('bad-exp-booking-alert-container');
        if (alertContainer) {
          if (guest?.bad_experience || (guest?.tags ?? []).includes('no_recomendar')) {
            alertContainer.innerHTML = `<div class="alert alert-warning">⚠️ <strong>Atención:</strong> este huésped tiene antecedentes de mala experiencia previa.</div>`;
          } else if ((guest?.tags ?? []).includes('vip')) {
            alertContainer.innerHTML = `<div class="alert alert-info">⭐ <strong>Huésped VIP</strong> — Dar atención preferencial.</div>`;
          } else {
            alertContainer.innerHTML = '';
          }
        }

        // ── Indicador cliente nuevo / frecuente ───────
        const guestBadge = document.getElementById('guest-booking-history-badge');
        if (guestBadge) {
          guestBadge.textContent = '⟳ Verificando...';
          guestBadge.className = 'guest-history-badge loading';
          try {
            const { count } = await this.db
              .from('bookings')
              .select('id', { count: 'exact', head: true })
              .eq('guest_id', item.dataset.id)
              .neq('status', 'cancelled');
            const n = count ?? 0;
            if (n === 0) {
              guestBadge.textContent  = '🆕 Cliente nuevo — primera reserva';
              guestBadge.className    = 'guest-history-badge new';
            } else {
              guestBadge.textContent  = `🔄 Huésped frecuente — ${n} reserva${n !== 1 ? 's' : ''} anterior${n !== 1 ? 'es' : ''}`;
              guestBadge.className    = 'guest-history-badge returning';
            }
          } catch {
            guestBadge.textContent = '';
          }
        }
      });
    });

    container.classList.remove('hidden');
  }

  // ── Historial de precios por unidad y mes ─────────
  async _loadPriceHistory(unitId) {
    if (!unitId) return;
    const hints = document.getElementById('price-history-hint');
    if (!hints) return;
    hints.innerHTML = '<span style="font-size:.72rem;color:var(--color-text-3)">⟳ Buscando historial...</span>';

    try {
      const now   = new Date();
      const month = now.getMonth() + 1;  // mes actual
      const monthPad = String(month).padStart(2, '0');
      // Buscar reservas de esta unidad en el mismo mes (cualquier año)
      const { data } = await this.db
        .from('booking_units')
        .select('bookings!inner(price_per_night, check_in, check_out, status)')
        .eq('unit_id', unitId)
        .not('bookings.status', 'in', '(cancelled,blocked)')
        .gt('bookings.price_per_night', 0)
        .like('bookings.check_in', `%-${monthPad}-%`)
        .limit(30);

      const prices = (data ?? [])
        .map(bu => bu.bookings?.price_per_night)
        .filter(p => p > 0);

      if (!prices.length) {
        // Fallback: buscar precio de cualquier mes reciente para esta unidad
        const { data: anyData } = await this.db
          .from('booking_units')
          .select('bookings!inner(price_per_night, check_in, status)')
          .eq('unit_id', unitId)
          .not('bookings.status', 'in', '(cancelled,blocked)')
          .gt('bookings.price_per_night', 0)
          .order('bookings.check_in', { ascending: false })
          .limit(5);
        const anyPrices = (anyData ?? []).map(bu => bu.bookings?.price_per_night).filter(p => p > 0);
        if (!anyPrices.length) { hints.innerHTML = ''; return; }
        const anyAvg = Math.round(anyPrices.reduce((a,b) => a+b,0) / anyPrices.length);
        const fmt = n => '$' + Math.round(n).toLocaleString('es-AR');
        const unitName = this.ctx.units.find(u => u.id === unitId)?.name ?? 'esta unidad';
        hints.innerHTML = `<span style="font-size:.72rem;color:var(--color-primary)">
          💡 Último precio registrado en <strong>${unitName}</strong>: <strong>${fmt(anyAvg)}</strong>/noche
        </span>`;
        return;
      }

      const avg      = Math.round(prices.reduce((a,b) => a+b,0) / prices.length);
      const min      = Math.min(...prices);
      const max      = Math.max(...prices);
      const fmt      = n => '$' + Math.round(n).toLocaleString('es-AR');
      const MONTHS   = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
      const unitName = this.ctx.units.find(u => u.id === unitId)?.name ?? 'esta unidad';

      hints.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;
          padding:6px 10px;background:var(--color-surface-2);
          border-radius:var(--r-md);border-left:3px solid var(--color-primary)">
          <span style="font-size:.72rem;color:var(--color-text-2)">
            💡 <strong>${unitName}</strong> en <strong>${MONTHS[month-1]}</strong>
            (${prices.length} reserva${prices.length!==1?'s':''} históricas):
            prom. <strong style="color:var(--color-primary)">${fmt(avg)}</strong>/noche
            ${min !== max ? `· rango ${fmt(min)}–${fmt(max)}` : ''}
          </span>
          <button style="font-size:.68rem;padding:2px 8px;border:1px solid var(--color-primary);
            border-radius:var(--r-sm);background:transparent;color:var(--color-primary);
            cursor:pointer" onclick="(function(){
              var el=document.getElementById('f-price');
              if(el){el.value=${avg};el.dispatchEvent(new Event('input',{bubbles:true}));}
            })()">
            Usar ${fmt(avg)}
          </button>
        </div>`;
    } catch { hints.innerHTML = ''; }
  }

  // ── Submit ────────────────────────────────────────
  // ── Voucher — Paso 5 ─────────────────────────────
  _renderVoucher() {
    const el = document.getElementById('booking-voucher');
    if (!el) return;

    // Collect data from previous steps
    const fn     = document.getElementById('f-firstname')?.value?.trim() ?? '';
    const ln     = document.getElementById('f-lastname')?.value?.trim()  ?? '';
    const dni    = document.getElementById('f-dni')?.value?.trim()       ?? '';
    const phone  = document.getElementById('f-phone')?.value?.trim()     ?? '';
    const email  = document.getElementById('f-email')?.value?.trim()     ?? '';
    const ci     = document.getElementById('f-checkin')?.value  ?? '';
    const co     = document.getElementById('f-checkout')?.value ?? '';
    const price  = parseFloat(document.getElementById('f-price')?.value  ?? 0);
    const notes  = document.getElementById('f-notes')?.value?.trim() ?? '';
    const adults   = parseInt(document.getElementById('f-adults')?.value   ?? 1);
    const children = parseInt(document.getElementById('f-children')?.value ?? 0);

    // Units
    const unitNames = (this.ctx?.units ?? [])
      .filter(u => this._selectedUnitIds.has(String(u.id)))
      .map(u => u.name).join(', ');

    // Source
    const selectedChip = document.querySelector('#f-source-selector .src-chip.selected');
    const source = selectedChip?.dataset?.source ?? 'direct';

    // Nights & financials
    const nightsN    = ci && co ? Math.round((new Date(co) - new Date(ci)) / 86400000) : 0;
    const discPct    = parseFloat(document.getElementById('f-discount')?.value    ?? 0);
    const surcharge  = parseFloat(document.getElementById('f-surcharge')?.value   ?? 0);
    const freeNights = parseInt(document.getElementById('f-free-nights')?.value ?? 0);
    const billable   = Math.max(0, nightsN - freeNights);
    const subtotal   = billable * price;
    const discount   = subtotal * discPct / 100;
    const total      = subtotal - discount + surcharge;
    const paid       = this._getTotalPaid();
    const balance    = total - paid;
    const fmt = n => '$' + Math.round(n).toLocaleString('es-AR');
    const fmtDate = d => d ? new Date(d + 'T12:00:00').toLocaleDateString('es-AR', {weekday:'short',day:'numeric',month:'short'}) : '—';

    // Payment rows
    const payRows = [];
    document.querySelectorAll('.payment-row').forEach(row => {
      const amt  = parseFloat(row.querySelector('.pay-amount')?.value) || 0;
      const meth = row.querySelector('.pay-method')?.value;
      const date = row.querySelector('.pay-date')?.value;
      const note = row.querySelector('.pay-note')?.value ?? '';
      if (amt > 0) {
        const labels = { cash:'Efectivo', transfer:'Transferencia', mercadopago:'MercadoPago',
          naranjax:'Naranja X', uala:'Ualá', debit_card:'Tarjeta Débito',
          credit_card:'Tarjeta Crédito (+10%)', credit_note:'Nota de Crédito / Voucher' };
        payRows.push({ label: labels[meth] ?? meth, amount: meth === 'credit_card' ? amt * 1.10 : amt, date, note });
      }
    });

    const statusText = paid <= 0 ? 'Sin seña' : balance <= 0 ? 'Pagado total' : 'Con seña';
    const statusColor = paid <= 0 ? '#f59e0b' : balance <= 0 ? '#16a34a' : '#fb7185';

    el.innerHTML = `
      <div class="voucher-header">
        <div class="voucher-hotel">${this.ctx?.hotel?.name ?? 'Barranca de Termas'}</div>
        <div class="voucher-title">${this._editingId ? 'Actualización de Reserva' : 'Nueva Reserva'}</div>
        <span class="voucher-status-pill" style="background:${statusColor}20;color:${statusColor};border:1px solid ${statusColor}40">${statusText}</span>
      </div>

      <div class="voucher-section">
        <div class="voucher-section-title">👤 Huésped</div>
        <div class="voucher-row"><strong>${(fn + ' ' + ln).trim() || '—'}</strong></div>
        ${dni   ? `<div class="voucher-row-sm">DNI: ${dni}</div>` : ''}
        ${phone ? `<div class="voucher-row-sm">📱 ${phone}</div>` : ''}
        ${email ? `<div class="voucher-row-sm">✉️ ${email}</div>` : ''}
      </div>

      <div class="voucher-section">
        <div class="voucher-section-title">🛏️ Estadía</div>
        <div class="voucher-dates-grid">
          <div><div class="voucher-label">CHECK-IN</div><div class="voucher-date-val">${fmtDate(ci)}</div></div>
          <div style="text-align:center;color:var(--color-text-3);font-size:1.2rem">→</div>
          <div><div class="voucher-label">CHECK-OUT</div><div class="voucher-date-val">${fmtDate(co)}</div></div>
        </div>
        <div class="voucher-row-sm" style="margin-top:6px">
          🌙 ${nightsN} noche${nightsN !== 1 ? 's' : ''}&nbsp;·&nbsp;
          👥 ${adults} adulto${adults !== 1 ? 's' : ''}${children ? ` + ${children} menor${children !== 1 ? 'es' : ''}` : ''}
        </div>
        <div class="voucher-row-sm">🏠 ${unitNames || '—'}</div>
      </div>

      <div class="voucher-section">
        <div class="voucher-section-title">💰 Finanzas</div>
        <div class="voucher-fin-row"><span>Precio por noche</span><span>${fmt(price)}</span></div>
        <div class="voucher-fin-row"><span>Noches facturadas (${billable})</span><span>${fmt(subtotal)}</span></div>
        ${discPct > 0   ? `<div class="voucher-fin-row voucher-disc"><span>Descuento ${discPct}%</span><span>−${fmt(discount)}</span></div>` : ''}
        ${surcharge > 0 ? `<div class="voucher-fin-row"><span>Recargo</span><span>+${fmt(surcharge)}</span></div>` : ''}
        ${freeNights > 0 ? `<div class="voucher-fin-row voucher-disc"><span>Noches sin cargo (${freeNights})</span><span>✓</span></div>` : ''}
        <div class="voucher-fin-row voucher-total"><span><strong>TOTAL</strong></span><span><strong>${fmt(total)}</strong></span></div>
        ${payRows.map(p => `
          <div class="voucher-fin-row" style="font-size:.78rem;color:var(--color-text-2)">
            <span>↳ ${p.label}${p.date ? ' · ' + p.date : ''}${p.note ? ' · ' + p.note : ''}</span>
            <span>${fmt(p.amount)}</span>
          </div>`).join('')}
        <div class="voucher-fin-row" style="margin-top:6px">
          <span>Abonado</span><span style="color:#16a34a;font-weight:600">${fmt(paid)}</span>
        </div>
        <div class="voucher-fin-row ${balance > 0 ? 'voucher-saldo-pending' : 'voucher-saldo-ok'}">
          <span><strong>${balance > 0 ? '⚠️ Saldo pendiente' : '✅ Sin saldo'}</strong></span>
          <span><strong>${balance > 0 ? fmt(balance) : '—'}</strong></span>
        </div>
      </div>

      ${notes ? `<div class="voucher-section">
        <div class="voucher-section-title">📝 Observaciones</div>
        <div class="voucher-notes">${notes}</div>
      </div>` : ''}`;

    // Wire voucher action buttons
    document.getElementById('btn-voucher-confirm')?.addEventListener('click', () => this._submit(), { once: true });
    document.getElementById('btn-voucher-pdf')?.addEventListener('click', () => this._exportVoucherPDF());
    document.getElementById('btn-voucher-whatsapp')?.addEventListener('click', () => this._sendVoucherToManager());
  }

  _exportVoucherPDF() {
    const fn   = document.getElementById('f-firstname')?.value?.trim() ?? '';
    const ln   = document.getElementById('f-lastname')?.value?.trim()  ?? '';
    const dni  = document.getElementById('f-dni')?.value?.trim()       ?? '';
    const phone= document.getElementById('f-phone')?.value?.trim()     ?? '';
    const email= document.getElementById('f-email')?.value?.trim()     ?? '';
    const ci   = document.getElementById('f-checkin')?.value  ?? '';
    const co   = document.getElementById('f-checkout')?.value ?? '';
    const price= parseFloat(document.getElementById('f-price')?.value ?? 0);
    const notes= document.getElementById('f-notes')?.value?.trim()     ?? '';
    const adults   = parseInt(document.getElementById('f-adults')?.value   ?? 1);
    const children = parseInt(document.getElementById('f-children')?.value ?? 0);

    const unitNames = (this.ctx?.units ?? [])
      .filter(u => this._selectedUnitIds.has(String(u.id)))
      .map(u => u.name).join(' / ');

    const nightsN    = ci && co ? Math.round((new Date(co) - new Date(ci)) / 86400000) : 0;
    const discPct    = parseFloat(document.getElementById('f-discount')?.value ?? 0);
    const surcharge  = parseFloat(document.getElementById('f-surcharge')?.value ?? 0);
    const freeNights = parseInt(document.getElementById('f-free-nights')?.value ?? 0);
    const billable   = Math.max(0, nightsN - freeNights);
    const subtotal   = billable * price;
    const discount   = subtotal * discPct / 100;
    const total      = subtotal - discount + surcharge;
    const paid       = this._getTotalPaid();
    const balance    = Math.max(0, total - paid);

    const fmt  = n => '$\u00a0' + Math.round(n).toLocaleString('es-AR');
    const fmtD = d => d ? new Date(d + 'T12:00:00').toLocaleDateString('es-AR', {weekday:'long', day:'numeric', month:'long', year:'numeric'}) : '—';
    const fmtDShort = d => d ? d.split('-').reverse().join('/') : '—';
    const now  = new Date().toLocaleDateString('es-AR', {day:'numeric',month:'long',year:'numeric'});

    const payRows = [];
    document.querySelectorAll('.payment-row').forEach(row => {
      const amt  = parseFloat(row.querySelector('.pay-amount')?.value) || 0;
      const meth = row.querySelector('.pay-method')?.value;
      const date = row.querySelector('.pay-date')?.value;
      const note = row.querySelector('.pay-note')?.value ?? '';
      if (amt > 0) {
        const labels = { cash:'Efectivo', transfer:'Transferencia', mercadopago:'MercadoPago',
          naranjax:'Naranja X', uala:'Ualá', debit_card:'Tarjeta Débito',
          credit_card:'Tarjeta Crédito (+10%)', credit_note:'Nota de Crédito/Voucher' };
        payRows.push({ label: labels[meth] ?? meth, amount: meth === 'credit_card' ? amt * 1.10 : amt, date: fmtDShort(date), note });
      }
    });

    const paxStr = `${adults} adulto${adults !== 1 ? 's' : ''}${children ? ` + ${children} menor${children !== 1 ? 'es' : ''}` : ''}`;
    const sourceChip = document.querySelector('#f-source-selector .src-chip.selected');
    const sourceLabel = sourceChip?.querySelector('span')?.textContent?.trim() ?? 'Directo';
    const statusText = paid <= 0 ? 'SIN SEÑA' : balance <= 0 ? 'PAGADO TOTAL' : 'CON SEÑA';
    const statusColor = paid <= 0 ? '#f59e0b' : balance <= 0 ? '#16a34a' : '#6366f1';

    const win = window.open('', '_blank');
    win.document.write(`<!DOCTYPE html><html lang="es"><head>
<meta charset="utf-8">
<title>Voucher — ${ln} ${fn}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family:'Inter',sans-serif; background:#f8fafc; color:#1e293b; padding:32px 24px; font-size:13px; }

  /* Header */
  .header { display:flex; align-items:center; justify-content:space-between; margin-bottom:28px; }
  .hotel-brand { display:flex; align-items:center; gap:12px; }
  .hotel-logo { width:44px; height:44px; border-radius:10px; background:linear-gradient(135deg,#6366f1,#8b5cf6); display:flex; align-items:center; justify-content:center; color:white; font-size:22px; }
  .hotel-name { font-size:16px; font-weight:700; color:#1e293b; }
  .hotel-sub  { font-size:11px; color:#64748b; margin-top:1px; }
  .voucher-label-badge { background:#6366f1; color:white; font-size:10px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; padding:5px 14px; border-radius:20px; }
  .divider { height:1px; background:linear-gradient(to right,#6366f1,transparent); margin:0 0 24px; }

  /* Status bar */
  .status-bar { background:#f1f5f9; border-radius:10px; padding:12px 18px; display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; border-left:4px solid ${statusColor}; }
  .status-label { font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:.08em; color:#64748b; }
  .status-value { font-size:13px; font-weight:700; color:${statusColor}; letter-spacing:.06em; }
  .status-date  { font-size:11px; color:#94a3b8; }

  /* Sections */
  .grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px; }
  .card { background:white; border:1px solid #e2e8f0; border-radius:10px; padding:16px 18px; }
  .card-title { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:#6366f1; margin-bottom:12px; display:flex; align-items:center; gap:6px; }
  .field { margin-bottom:8px; }
  .field:last-child { margin-bottom:0; }
  .field-label { font-size:10px; font-weight:600; text-transform:uppercase; letter-spacing:.07em; color:#94a3b8; margin-bottom:2px; }
  .field-value { font-size:13px; font-weight:500; color:#1e293b; }
  .field-value.large { font-size:15px; font-weight:700; }

  /* Dates banner */
  .dates-banner { background:linear-gradient(135deg,#6366f1,#8b5cf6); color:white; border-radius:10px; padding:18px 20px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; }
  .dates-block { text-align:center; flex:1; }
  .dates-block-lbl { font-size:10px; font-weight:600; letter-spacing:.1em; opacity:.7; margin-bottom:4px; }
  .dates-block-val { font-size:14px; font-weight:700; }
  .dates-block-sub { font-size:11px; opacity:.75; margin-top:2px; }
  .dates-arrow { font-size:22px; opacity:.6; }
  .nights-pill { background:rgba(255,255,255,.2); border-radius:20px; padding:4px 14px; font-size:12px; font-weight:600; }

  /* Finance table */
  .finance-card { background:white; border:1px solid #e2e8f0; border-radius:10px; overflow:hidden; margin-bottom:20px; }
  .finance-row { display:flex; justify-content:space-between; align-items:center; padding:9px 18px; border-bottom:1px solid #f1f5f9; font-size:12px; }
  .finance-row:last-child { border-bottom:none; }
  .finance-row.subtotal { font-weight:500; }
  .finance-row.disc { color:#16a34a; }
  .finance-row.total { background:#f8fafc; font-size:14px; font-weight:700; color:#1e293b; padding:12px 18px; }
  .finance-row.payment-row-item { color:#64748b; font-size:11px; padding:6px 18px 6px 30px; background:#fafafa; }
  .finance-row.paid-row { color:#16a34a; font-weight:600; }
  .finance-row.balance-row { background:${balance > 0 ? '#fef3c7' : '#f0fdf4'}; color:${balance > 0 ? '#92400e' : '#14532d'}; font-weight:700; font-size:13px; padding:12px 18px; }

  /* Notes */
  .notes-card { background:#fafafa; border:1px dashed #cbd5e1; border-radius:10px; padding:14px 18px; margin-bottom:20px; }
  .notes-text  { font-size:12px; color:#475569; font-style:italic; line-height:1.5; }

  /* Footer */
  .footer { text-align:center; margin-top:24px; padding-top:16px; border-top:1px solid #e2e8f0; }
  .footer p { font-size:10px; color:#94a3b8; line-height:1.6; }
  .footer strong { color:#6366f1; }

  @media print {
    body { background:white; padding:16px; }
    .dates-banner { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
    .finance-row.balance-row, .finance-row.total { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  }
</style></head><body>

<div class="header">
  <div class="hotel-brand">
    <div class="hotel-logo">🏨</div>
    <div>
      <div class="hotel-name">Barranca de Termas</div>
      <div class="hotel-sub">Complejo de Apartamentos Turísticos</div>
    </div>
  </div>
  <div class="voucher-label-badge">Voucher de Reserva</div>
</div>
<div class="divider"></div>

<div class="status-bar">
  <div>
    <div class="status-label">Estado de pago</div>
    <div class="status-value">${statusText}</div>
  </div>
  <div style="text-align:right">
    <div class="status-label">Canal</div>
    <div style="font-size:12px;font-weight:600;color:#475569">${sourceLabel}</div>
  </div>
  <div style="text-align:right">
    <div class="status-label">Emitido</div>
    <div class="status-date">${now}</div>
  </div>
</div>

<!-- Datos del Huésped + Unidad -->
<div class="grid-2">
  <div class="card">
    <div class="card-title">👤 Datos del Huésped</div>
    <div class="field">
      <div class="field-label">Nombre completo</div>
      <div class="field-value large">${(ln + ', ' + fn).trim().replace(/^, /,'') || '—'}</div>
    </div>
    ${dni   ? `<div class="field"><div class="field-label">DNI / Documento</div><div class="field-value">${dni}</div></div>` : ''}
    ${phone ? `<div class="field"><div class="field-label">Teléfono</div><div class="field-value">${phone}</div></div>` : ''}
    ${email ? `<div class="field"><div class="field-label">Email</div><div class="field-value">${email}</div></div>` : ''}
  </div>
  <div class="card">
    <div class="card-title">🏠 Alojamiento</div>
    <div class="field">
      <div class="field-label">Unidad / Departamento</div>
      <div class="field-value large">${unitNames || '—'}</div>
    </div>
    <div class="field">
      <div class="field-label">Huéspedes</div>
      <div class="field-value">${paxStr}</div>
    </div>
  </div>
</div>

<!-- Fechas -->
<div class="dates-banner">
  <div class="dates-block">
    <div class="dates-block-lbl">CHECK-IN</div>
    <div class="dates-block-val">${fmtDShort(ci)}</div>
    <div class="dates-block-sub">${fmtD(ci).split(',')[0] ?? ''}</div>
  </div>
  <div style="text-align:center">
    <div class="dates-arrow">→</div>
    <div class="nights-pill">${nightsN} noche${nightsN !== 1 ? 's' : ''}</div>
  </div>
  <div class="dates-block">
    <div class="dates-block-lbl">CHECK-OUT</div>
    <div class="dates-block-val">${fmtDShort(co)}</div>
    <div class="dates-block-sub">${fmtD(co).split(',')[0] ?? ''}</div>
  </div>
</div>

<!-- Liquidación -->
<div class="finance-card">
  <div class="finance-row subtotal">
    <span>Precio por noche</span><span>${fmt(price)}</span>
  </div>
  <div class="finance-row subtotal">
    <span>Noches (${billable}${freeNights ? ` facturables de ${nightsN}` : ''})</span><span>${fmt(subtotal)}</span>
  </div>
  ${discPct > 0    ? `<div class="finance-row disc"><span>Descuento ${discPct}%</span><span>− ${fmt(discount)}</span></div>` : ''}
  ${surcharge > 0  ? `<div class="finance-row"><span>Recargo adicional</span><span>+ ${fmt(surcharge)}</span></div>` : ''}
  <div class="finance-row total">
    <span>TOTAL ESTADÍA</span><span>${fmt(total)}</span>
  </div>
  ${payRows.map(p => `
  <div class="finance-row payment-row-item">
    <span>↳ ${p.label}${p.date ? ' · ' + p.date : ''}${p.note ? ' · ' + p.note : ''}</span>
    <span>${fmt(p.amount)}</span>
  </div>`).join('')}
  ${paid > 0 ? `<div class="finance-row paid-row"><span>Total abonado</span><span>${fmt(paid)}</span></div>` : ''}
  <div class="finance-row balance-row">
    <span>${balance > 0 ? '⚠️ Saldo pendiente al check-in' : '✅ Sin saldo pendiente'}</span>
    <span>${balance > 0 ? fmt(balance) : '—'}</span>
  </div>
</div>

${notes ? `
<div class="notes-card">
  <div class="card-title" style="margin-bottom:8px">📝 Observaciones</div>
  <div class="notes-text">${notes}</div>
</div>` : ''}

<div class="footer">
  <p>Este documento es un comprobante interno de reserva generado por <strong>MILA PMS</strong>.<br>
  Barranca de Termas — Departamentos Turísticos · <em>Documento emitido el ${now}</em></p>
</div>

</body></html>`);
    win.document.close();
    setTimeout(() => win.print(), 500);
  }

  _sendVoucherToManager() {
    const fn      = document.getElementById('f-firstname')?.value?.trim() ?? '';
    const ln      = document.getElementById('f-lastname')?.value?.trim()  ?? '';
    const dni     = document.getElementById('f-dni')?.value?.trim()       ?? '';
    const phone   = document.getElementById('f-phone')?.value?.trim()     ?? '';
    const ci      = document.getElementById('f-checkin')?.value  ?? '';
    const co      = document.getElementById('f-checkout')?.value ?? '';
    const price   = parseFloat(document.getElementById('f-price')?.value ?? 0);
    const adults  = parseInt(document.getElementById('f-adults')?.value   ?? 1);
    const children= parseInt(document.getElementById('f-children')?.value ?? 0);
    const notes   = document.getElementById('f-notes')?.value?.trim() ?? '';

    const unitNames = (this.ctx?.units ?? [])
      .filter(u => this._selectedUnitIds.has(String(u.id)))
      .map(u => u.name).join(', ');

    const nightsN  = ci && co ? Math.round((new Date(co) - new Date(ci)) / 86400000) : 0;
    const discPct  = parseFloat(document.getElementById('f-discount')?.value ?? 0);
    const surcharge= parseFloat(document.getElementById('f-surcharge')?.value ?? 0);
    const freeNights = parseInt(document.getElementById('f-free-nights')?.value ?? 0);
    const billable = Math.max(0, nightsN - freeNights);
    const subtotal = billable * price;
    const discount = subtotal * discPct / 100;
    const total    = subtotal - discount + surcharge;
    const paid     = this._getTotalPaid();
    const balance  = Math.max(0, total - paid);

    // Origen/canal
    const sourceChip = document.querySelector('#f-source-selector .src-chip.selected');
    const sourceLabel = sourceChip?.querySelector('span')?.textContent?.trim() ?? 'Directo';

    const paxStr = `${adults} adulto${adults !== 1 ? 's' : ''}${children ? ` + ${children} menor${children !== 1 ? 'es' : ''}` : ''}`;
    const fmt = n => '$' + Math.round(n).toLocaleString('es-AR');
    const fmtD = d => d ? d.split('-').reverse().join('/') : '—';

    // Exact format requested
    const text =
      `🏨 *Nueva Reserva*\n` +
      `*Apellido y Nombre:* ${ln} ${fn}\n` +
      `*DNI:* ${dni || '—'}\n` +
      `*Celular de contacto:* ${phone || '—'}\n` +
      `*Check-in:* ${fmtD(ci)}\n` +
      `*Check-out:* ${fmtD(co)} (${nightsN} noche${nightsN !== 1 ? 's' : ''})\n` +
      `*Tipo de departamento:* ${unitNames || '—'}\n` +
      `*Cantidad de personas:* ${paxStr}\n` +
      `*Saldo pendiente al ingreso:* ${fmt(balance)}\n\n` +
      `📝 *Nota y observaciones:* _${[sourceLabel, notes].filter(Boolean).join(' · ') || 'Sin observaciones'}_`;

    const MANAGER_PHONE = '5492236848043'; // +54 9 223 684-8043
    window.open(`https://wa.me/${MANAGER_PHONE}?text=${encodeURIComponent(text)}`, '_blank');
  }

  async _submit() {
    if (!this._validateAll()) return;

    const btn = document.getElementById('btn-step-next');
    if (btn) { btn.disabled = true; btn.textContent = 'Guardando...'; }

    let _safetyTimer = setTimeout(() => {
      if (btn) { btn.disabled = false; btn.textContent = this._editingId ? 'Guardar cambios' : 'Confirmar reserva'; }
      showToast('La operación tardó demasiado. Verificá tu conexión.', 'error');
    }, 30000);

    try {
      const ci    = document.getElementById('f-checkin').value;
      const co    = document.getElementById('f-checkout').value;
      const price = parseFloat(document.getElementById('f-price').value) || 0;
      const disc  = parseFloat(document.getElementById('f-discount').value) || 0;
      const surch = parseFloat(document.getElementById('f-surcharge').value) || 0;
      const freeN = parseInt(document.getElementById('f-free-nights').value) || 0;
      const dep   = parseFloat(document.getElementById('f-deposit').value) || 0;
      const notes = document.getElementById('f-notes').value.trim();
      const source = document.querySelector('input[name="booking-source"]:checked')?.value ?? 'direct';

      const nights   = Math.round((new Date(co) - new Date(ci)) / 86400000);
      const billable = Math.max(0, nights - freeN);
      const subtotal = price * billable;
      const discAmt  = subtotal * (disc / 100);
      const total    = Math.max(0, subtotal - discAmt + surch);
      const paid     = this._getTotalPaid();
      const balance  = total - paid;

      // ── Validar superposición de unidades ────────────
      const selectedUnits = [...this._selectedUnitIds];
      if (selectedUnits.length > 0 && ci && co) {
        const { data: conflicts } = await this.db
          .from('booking_units')
          .select('unit_id, bookings!inner(id, check_in, check_out, status, guests!bookings_guest_id_fkey(first_name,last_name))')
          .in('unit_id', selectedUnits)
          .not('bookings.status', 'in', '(cancelled,blocked)')
          .lt('bookings.check_in', co)
          .gt('bookings.check_out', ci);

        const realConflicts = (conflicts ?? []).filter(c =>
          !this._editingId || c.bookings?.id !== this._editingId
        );
        if (realConflicts.length) {
          const g = realConflicts[0].bookings?.guests;
          const name = g ? `${g.first_name} ${g.last_name}` : 'otro huésped';
          showToast(`⚠️ Superposición: "${name}" ya tiene esa unidad en esas fechas.`, 'error');
          if (btn) { btn.disabled = false; btn.textContent = this._editingId ? 'Guardar cambios' : 'Confirmar reserva'; }
          clearTimeout(_safetyTimer);
          return;
        }
      }

      // ── Capturar estado ANTES (para audit log) ────────
      let bookingBefore = null;
      if (this._editingId) {
        const { data: prev } = await this.db
          .from('bookings')
          .select('check_in,check_out,price_per_night,total_amount,status,source,notes')
          .eq('id', this._editingId).single();
        bookingBefore = prev;
      }

      // Upsert huésped
      let guestId = this._selectedGuestId;
      const guestPayload = {
        hotel_id:   this.ctx.hotelId,
        first_name: document.getElementById('f-firstname').value.trim(),
        last_name:  document.getElementById('f-lastname').value.trim(),
        dni:        document.getElementById('f-dni').value.trim()   || null,
        phone:      document.getElementById('f-phone').value.trim() || null,
        email:      document.getElementById('f-email').value.trim() || null,
      };

      if (guestId) {
        await this.db.from('guests').update(guestPayload).eq('id', guestId);
      } else {
        const { data: newGuest, error: gErr } = await this.db
          .from('guests').insert(guestPayload).select('id').single();
        if (gErr) throw gErr;
        guestId = newGuest.id;
      }

      // ── Columnas CORE (siempre existen en la DB) ──────────────
      const corePayload = {
        hotel_id:         this.ctx.hotelId,
        guest_id:         guestId,
        check_in:         ci,
        check_out:        co,
        // nights: GENERATED ALWAYS AS en PostgreSQL — nunca insertar
        source,
        price_per_night:  price,
        discount_pct:     disc,
        surcharge_amount: surch,
        total_amount:     total,
        total_paid:       paid,
        balance,
        notes:            notes || null,
        status:           balance <= 0 ? 'paid' : paid > 0 ? 'partial' : 'pending',
      };

      // ── Columnas opcionales — se agregan en UPDATE separado ──────
      const pax      = (parseInt(document.getElementById('f-adults')?.value) || 1)
                     + (parseInt(document.getElementById('f-children')?.value) || 0);
      const adults   = parseInt(document.getElementById('f-adults')?.value)   || 1;
      const children = parseInt(document.getElementById('f-children')?.value) || 0;

      let bookingId = this._editingId;
      if (bookingId) {
        // UPDATE — intentar con free_nights primero
        let { error: upErr } = await this.db.from('bookings').update({
          ...corePayload, free_nights: freeN
        }).eq('id', bookingId);
        if (upErr?.message?.includes('free_nights')) {
          // Columna no existe aún → guardar sin ella
          const { error: upErr2 } = await this.db.from('bookings').update(corePayload).eq('id', bookingId);
          if (upErr2) throw new Error('No fue posible actualizar la reserva: ' + upErr2.message);
        } else if (upErr) {
          throw new Error('No fue posible actualizar la reserva: ' + upErr.message);
        }
        await this.db.from('booking_units').delete().eq('booking_id', bookingId);
        await this.db.from('payments').delete().eq('booking_id', bookingId);
      } else {
        // INSERT — intentar con free_nights primero
        let { data: newB, error: insErr } = await this.db
          .from('bookings').insert({ ...corePayload, free_nights: freeN })
          .select('id').single();
        if (insErr?.message?.includes('free_nights') || insErr?.message?.includes('does not exist')) {
          // Columna no existe → reintentar sin ella
          const { data: newB2, error: insErr2 } = await this.db
            .from('bookings').insert(corePayload).select('id').single();
          if (insErr2) throw new Error('No fue posible crear la reserva: ' + insErr2.message);
          newB = newB2;
        } else if (insErr) {
          throw new Error('No fue posible crear la reserva: ' + insErr.message);
        }
        bookingId = newB.id;
      }

      // ── Columnas opcionales (pax, comisiones) — silencioso si no existen ──
      try {
        await this.db.from('bookings').update({ pax, adults, children }).eq('id', bookingId);
      } catch { /* columnas opcionales */ }

      // Insertar unidades — sin hotel_id (no existe en booking_units)
      const unitRows = [...this._selectedUnitIds].map(uid => ({
        booking_id: bookingId, unit_id: uid,
      }));
      if (unitRows.length) {
        const { error: buErr } = await this.db.from('booking_units').insert(unitRows);
        if (buErr) throw new Error('Error asignando unidades: ' + buErr.message);
      }

      // Insertar pagos (incluye notes del nuevo campo)
      const payRows = [];
      document.querySelectorAll('.payment-row').forEach(row => {
        const amt  = parseFloat(row.querySelector('.pay-amount')?.value) || 0;
        const meth = row.querySelector('.pay-method')?.value;
        const date = row.querySelector('.pay-date')?.value;
        const note = row.querySelector('.pay-note')?.value?.trim() || null;
        if (amt > 0) {
          const isCc = meth === 'credit_card';
          payRows.push({
            booking_id:   bookingId,
            hotel_id:     this.ctx.hotelId,
            method:       meth,
            amount:       isCc ? amt * 1.10 : amt,
            // payment_date añadido en migration_complete_v8.sql
            // Si la columna no existe todavía, se ignora el error de schema
            payment_date: date || toISODate(new Date()),
            notes:        note,
          });
        }
      });
      if (payRows.length) {
        const { error: pmErr } = await this.db.from('payments').insert(payRows);
        if (pmErr) throw new Error('Error registrando pago: ' + pmErr.message);
      }

      const _logVerb    = this._editingId ? 'UPDATE' : 'CREATE';
      const _logSummary = this._editingId
        ? `Actualizada: ${ci} → ${co}, $${price}/noche, total $${total}`
        : `Creada: ${ci} → ${co}, $${price}/noche, total $${total}`;
      const _changes = bookingBefore ? {
        before: bookingBefore,
        after:  { check_in: ci, check_out: co, price_per_night: price, total_amount: total, status: balance <= 0 ? 'paid' : paid > 0 ? 'partial' : 'pending', source, notes: notes || null },
      } : null;
      await logAction(_logVerb, 'booking', String(bookingId), _logSummary, _changes);

      showToast(this._editingId ? 'Reserva actualizada ✓' : 'Reserva creada ✓', 'success');
      Sound?.[this._editingId ? 'success' : 'newBooking']?.();

      // Email de confirmación — solo en creación nueva (no edición)
      if (!this._editingId) {
        const guestEmail = document.getElementById('f-email')?.value?.trim();
        // Invocar async sin bloquear el UI
        this.db.functions?.invoke?.('booking-confirmation', {
          body: { bookingId: String(bookingId) },
        }).catch((err) => console.warn('[BookingForm] confirmation email:', err));
      }

      // Invalidar cache para que el calendario traiga datos frescos
      cache.invalidate('bookings');

      // Micro-animación: pulso en la barra nueva/editada
      Bus.emit(EVENTS.CAL_PULSE_BAR, { bookingId: String(bookingId) });

      if (balance <= 0 && paid > 0) {
        document.dispatchEvent(new CustomEvent('booking:fullypaid'));
      }

      this.close();
      document.dispatchEvent(new CustomEvent('booking:changed'));

    } catch (err) {
      console.error('[MILA] Booking save error:', err);
      // Mostrar el error real siempre — ayuda a diagnosticar
      const raw = err?.message ?? String(err) ?? 'Error desconocido';
      const userMsg = raw.includes('violates foreign key')
        ? 'ID de unidad o huésped inválido. Recargá la página.'
        : raw.includes('violates not-null')
        ? 'Falta un campo requerido en la base de datos.'
        : raw.includes('duplicate')
        ? 'Ya existe una reserva con esos datos.'
        : raw.includes('permission') || raw.includes('policy')
        ? 'Sin permisos. Verificá las políticas RLS en Supabase.'
        : raw;
      showToast(`❌ ${userMsg}`, 'error');
    } finally {
      clearTimeout(_safetyTimer);
      if (btn) {
        btn.disabled   = false;
        btn.textContent = this._editingId ? 'Guardar cambios' : 'Confirmar reserva';
      }
    }
  }
}
