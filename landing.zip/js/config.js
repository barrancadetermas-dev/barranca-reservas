// ═══════════════════════════════════════════════════
// config.js — Credenciales reales de Supabase
// ⚠️  NUNCA commitear este archivo (en .gitignore)
// ═══════════════════════════════════════════════════

export const SUPABASE_URL      = 'https://TU_PROYECTO_ID.supabase.co';
export const SUPABASE_ANON_KEY = 'TU_ANON_KEY_AQUI';
